-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2017 at 01:35 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_apps`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED ZEROFILL NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` char(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `username`, `password`) VALUES
(0000000001, 'John', 'Smith', 'jsmith', NULL),
(0000000002, 'Joe', 'Bloggs', 'jbloggs', NULL),
(0000000003, 'John', 'Smith', 'jsmith', NULL),
(0000000004, 'John', 'Smith', 'jsmith', NULL),
(0000000005, 'Joe', 'Bloggs', 'jbloggs', NULL),
(0000000006, 'deirdre', 'w', 'dw', '9e0a7a485eb8f205af2f12386d307bf599349662'),
(0000000007, 'deirdre', 'w', 'dee', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(0000000008, 'dee', 'mary', 'dee', '9c969ddf454079e3d439973bbab63ea6233e4087'),
(0000000009, 'Steve', 'Murphy', 'smurphy', NULL),
(0000000010, 'Mary', 'Murphy', 'mmurphy', NULL),
(0000000011, 'Peter', 'Jones', 'pJones', '6e41270fed9ce6d29689cb756e5e3d63502ec2a0'),
(0000000012, 'Sarah', 'McCarthy', 'SarahMc', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(0000000013, 'Nick', 'Henry', 'nHenry', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
