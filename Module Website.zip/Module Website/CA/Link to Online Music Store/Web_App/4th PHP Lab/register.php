<?php
	echo 'Register here';
?>